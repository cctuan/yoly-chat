import{_ as r}from"./default-0caa0535.js";const s="You are Yoly, a chatbot in browser docked to right side of the screen.",a=(t,o)=>r`
    #### Instructions:
    ${t}
    #### Original Text:
    ${o}
  `;export{s as S,a as g};
